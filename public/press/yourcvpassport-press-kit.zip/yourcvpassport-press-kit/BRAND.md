# YourCVPassport · Press kit

## Contents
- `yourcvpassport-logo.svg` / `.png`: primary logo (light backgrounds).
- `yourcvpassport-logo-dark-bg.svg` / `.png`: logo for dark backgrounds.
- `yourcvpassport-icon.svg` / `.png`: icon-only version (512 x 512).
- `OFL.txt`: license of the typeface used in the logo.

## Logo typeface
The wordmark is set in **Inter Bold** (weight 700, default tracking) by Rasmus Andersson / The Inter Project Authors,
licensed under the **SIL Open Font License 1.1** (see `OFL.txt`, https://github.com/rsms/inter).
The logo files are already converted to outlines, so no font needs to be installed to use them.

## Brand colors
| Name | HEX | Use |
|---|---|---|
| CV Blue | #2563EB | Primary brand color, logo on light backgrounds |
| CV Blue Light | #60A5FA | Logo and accents on dark backgrounds |
| CV Blue Dark | #1E40AF | Hover states, gradients |
| Dark Gray | #1F2937 | Body text |
| Light Gray | #F8F9FA | Light backgrounds |
| Green | #10B981 | Success / verified states |

## Usage
- Keep clear space around the logo of at least the height of the letter "Y".
- Do not stretch, rotate, recolor, add effects or outline the logo.
- Use the primary logo on white or light backgrounds and the dark-background version on dark surfaces.
- Minimum width of the full logo: 120 px on screen.
- Always write the name as one word: YourCVPassport.

## Contact
Press inquiries: press@yourcvpassport.com · https://yourcvpassport.com/about/press

---

# YourCVPassport · Kit de prensa (ES)

## Contenido
- `yourcvpassport-logo.svg` / `.png`: logo principal (fondos claros).
- `yourcvpassport-logo-dark-bg.svg` / `.png`: logo para fondos oscuros.
- `yourcvpassport-icon.svg` / `.png`: version solo icono (512 x 512).
- `OFL.txt`: licencia de la tipografia del logo.

## Tipografia del logo
El logotipo usa **Inter Bold** (peso 700, espaciado por defecto), de Rasmus Andersson / The Inter Project Authors,
con licencia **SIL Open Font License 1.1** (ver `OFL.txt`, https://github.com/rsms/inter).
Los archivos del logo ya estan convertidos a trazos: no hace falta instalar la fuente para usarlos.

## Colores de marca
Azul CV #2563EB (principal) · Azul claro #60A5FA (fondos oscuros) · Azul oscuro #1E40AF · Gris oscuro #1F2937 · Gris claro #F8F9FA · Verde #10B981.

## Uso
- Deja alrededor del logo un margen minimo igual a la altura de la letra "Y".
- No deformes, gires, recolorees ni anadas efectos al logo.
- Usa el logo principal sobre fondos claros y la version para fondos oscuros sobre superficies oscuras.
- Ancho minimo del logo completo: 120 px en pantalla.
- Escribe siempre el nombre junto: YourCVPassport.

## Contacto
Prensa: press@yourcvpassport.com · https://yourcvpassport.com/nosotros/prensa
